<!DOCTYPE html>
<html>
<head>
	<title>Students</title>
</head>
<body>




<?php $__currentLoopData = $studenttable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registered): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
	 <?php echo e($registered->first_name); ?>

	<?php echo e($registered->last_name); ?>

	 <?php echo e($registered->middle_initial); ?>

	<?php echo e($registered->student_id); ?>

	<?php echo e($registered->course); ?>

	<?php echo e($registered->address); ?>

	<?php echo e($registered->guardian); ?>

	}
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>