<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>
<form method="post" action="sendData">
enter lowest value:<input type="text">
enter highest value:<input type="text">
enter class interval:<input type="text">
<button>send</button>
</form>

</body>
</html>