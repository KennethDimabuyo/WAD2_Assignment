<!DOCTYPE html>
<html>
<head>
	<title>Students</title>
</head>
<body>




<?php echo e(csrf_field()); ?>


<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registered): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<table>
	<tr>
		<td>
			first name
		</td>
				<td>
			last name
		</td>
				<td>
			middle name
		</td>
				<td>
			student id
		</td>
				<td>
			course
		</td>
				<td>
			address
		</td>
				<td>
			guardian
		</td>

	</tr>

		<tr>
		<td>
			<?php echo e($registered->first_name); ?>

		</td>
				<td>
			<?php echo e($registered->last_name); ?>

		</td>
				<td>
			<?php echo e($registered->middle_initial); ?>

		</td>
				<td>
			<?php echo e($registered->student_id); ?>

		</td>
				<td>
			<?php echo e($registered->course); ?>

		</td>
				<td>
			<?php echo e($registered->address); ?>

		</td>
				<td>
			<?php echo e($registered->guardian); ?>

		</td>

	</tr>
</table>
	 
	
	 
	
	
	
	
	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	


</body>
</html>